#!/usr/bin/env bash
mkdir data/example -p
mkdir data/example/globalPCA -p