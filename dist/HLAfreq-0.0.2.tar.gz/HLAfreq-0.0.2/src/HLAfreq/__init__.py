from .HLAfreq import *
